package org.shreya.gpugrid;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class GpugridApplication {

    public static void main(String[] args) {
        System.setProperty("user.timezone", "Asia/Kolkata");

        SpringApplication.run(GpugridApplication.class, args);
    }

}
